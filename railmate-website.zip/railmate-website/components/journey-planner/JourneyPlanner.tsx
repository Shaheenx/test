/**
 * RailMate Bangladesh — Journey Planner (website)
 * -------------------------------------------------
 * The website's flagship, category-defining feature: a knowledge-graph
 * route planner that finds direct, 1-transfer, and 2-transfer journeys
 * across the whole Bangladesh Railway network, with a transparent
 * confidence score on every result. No other Bangladeshi rail platform
 * offers multi-transfer route planning today.
 *
 * Fully theme-aware (light/dark via design tokens) and fully bilingual
 * (English / বাংলা via useI18n) — station names, route/confidence labels,
 * disclaimers, and the "no route found" guidance are all localized.
 */

'use client';

import { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import {
  Train,
  ArrowsLeftRight,
  MagnifyingGlass,
  MapPin,
  CircleNotch,
  Warning,
  CheckCircle,
  ArrowRight,
  X,
} from '@phosphor-icons/react';
import { useI18n } from '@/lib/i18n';
import type { Locale } from '@/lib/i18n';
import Badge from '@/components/ui/Badge';
import { RouteEngine } from './routeEngine';
import type {
  JourneyResult,
  DirectJourney,
  OneTransferJourney,
  TwoTransferJourney,
  NotFoundResult,
  JourneyLeg,
  Station,
  TrainMeta,
  ConfidenceLevel,
  RouteType,
} from './routeEngine';
import { STATIONS, TRAINS, STOP_SEQUENCES } from './railmateData';

// ─── Engine singleton ─────────────────────────────────────────────────────────

const engine = new RouteEngine(STOP_SEQUENCES, TRAINS, STATIONS);

// ─── i18n dict typing (derived from useI18n so it always stays in sync) ──────

type I18n = ReturnType<typeof useI18n>;
type JPDict = I18n['t']['journey_planner'];

// ─── Small helpers ────────────────────────────────────────────────────────────

const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

function localizeNumber(n: number | string, locale: Locale): string {
  const s = String(n);
  if (locale !== 'bn') return s;
  return s.replace(/[0-9]/g, (d) => BN_DIGITS[Number(d)]);
}

function stationDisplay(code: string, locale: Locale): string {
  const s = STATIONS.find((st) => st.code === code);
  if (!s) return code;
  return locale === 'bn' && s.nameBn ? s.nameBn : s.nameEn;
}

function displayName(s: Station, locale: Locale): string {
  return locale === 'bn' && s.nameBn ? s.nameBn : s.nameEn;
}

function scoreExplain(score: number, jp: JPDict): string {
  if (score >= 50) return jp.score_explain_1;
  if (score >= 35) return jp.score_explain_2;
  if (score >= 20) return jp.score_explain_3;
  return jp.score_explain_4;
}

const DATA_NOTE_KEY: Record<Exclude<RouteType, 'not_found'>, keyof JPDict> = {
  direct: 'data_note_direct',
  one_transfer: 'data_note_one_transfer',
  two_transfer: 'data_note_two_transfer',
};

const CONF_BADGE_VARIANT: Record<ConfidenceLevel, 'success' | 'info' | 'warning'> = {
  medium: 'success',
  'low-medium': 'info',
  low: 'warning',
};

const CONF_LABEL_KEY: Record<ConfidenceLevel, keyof JPDict> = {
  medium: 'confidence_medium',
  'low-medium': 'confidence_low_medium',
  low: 'confidence_low',
};

const ROUTE_BADGE_CLASSES: Record<RouteType, string> = {
  direct: 'bg-primary/10 text-primary border border-primary/20',
  one_transfer: 'bg-info/10 text-info border border-info/20',
  two_transfer: 'bg-accent/10 text-accent border border-accent/20',
  not_found: 'bg-text-tertiary/10 text-text-tertiary border border-border-subtle',
};

const ROUTE_TYPE_LABEL_KEY: Record<RouteType, keyof JPDict> = {
  direct: 'route_type_direct',
  one_transfer: 'route_type_one_transfer',
  two_transfer: 'route_type_two_transfer',
  not_found: 'route_type_not_found',
};

// ─── Popular routes (well-known hub-to-hub pairs) ────────────────────────────

const POPULAR_ROUTE_CODES: [string, string][] = [
  ['DHKA', 'CTG'],
  ['DHKA', 'SYT'],
  ['DHKA', 'RAJ'],
  ['DHKA', 'KHU'],
];

// ─── Presentational pieces ────────────────────────────────────────────────────

function RouteTypeBadge({ type, jp }: { type: RouteType; jp: JPDict }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full font-inter ${ROUTE_BADGE_CLASSES[type]}`}
    >
      <Train size={13} weight="fill" />
      {jp[ROUTE_TYPE_LABEL_KEY[type]]}
    </span>
  );
}

function ScoreBar({ score, jp, locale }: { score: number; jp: JPDict; locale: Locale }) {
  const barColor =
    score >= 45 ? 'bg-primary' : score >= 25 ? 'bg-info' : 'bg-accent';
  return (
    <div className="flex items-center gap-2 text-xs text-text-tertiary font-inter">
      <span className="flex-shrink-0">{jp.confidence_score_label}</span>
      <div className="flex-1 bg-bg-elevated rounded-full h-1.5 max-w-[120px] overflow-hidden">
        <div
          className={`h-1.5 rounded-full ${barColor} transition-all duration-700 ease-out`}
          style={{ width: `${score}%` }}
        />
      </div>
      <span className="text-text-tertiary flex-shrink-0">
        {localizeNumber(score, locale)}/{localizeNumber(100, locale)}
      </span>
    </div>
  );
}

function TrainChips({ trains, jp, max = 3 }: { trains: TrainMeta[]; jp: JPDict; max?: number }) {
  const shown = trains.slice(0, max);
  const extra = trains.length - max;
  return (
    <div className="flex flex-wrap gap-1.5 mt-2">
      {shown.map((t) => (
        <span
          key={t.number}
          className="inline-flex items-center gap-1.5 text-[11px] bg-bg-elevated border border-border-subtle rounded-md px-2 py-1 text-text-secondary font-inter"
        >
          <span className="font-mono font-semibold text-primary">#{t.number}</span>
          {t.name}
        </span>
      ))}
      {extra > 0 && (
        <span className="text-[11px] text-text-tertiary px-1.5 py-1 font-inter">
          +{extra} {jp.more_trains}
        </span>
      )}
    </div>
  );
}

function LegCard({
  leg,
  stepNumber,
  isLast,
  jp,
  locale,
}: {
  leg: JourneyLeg;
  stepNumber: number;
  isLast: boolean;
  jp: JPDict;
  locale: Locale;
}) {
  return (
    <div className="flex gap-3.5">
      <div className="flex flex-col items-center">
        <div className="w-7 h-7 rounded-full bg-primary text-white text-[12px] font-bold flex items-center justify-center flex-shrink-0 shadow-sm shadow-primary/30">
          {localizeNumber(stepNumber, locale)}
        </div>
        {!isLast && <div className="w-px flex-1 bg-border-subtle mt-1.5" />}
      </div>
      <div className="pb-5 flex-1 min-w-0">
        <div className="flex items-center gap-1.5 text-sm font-semibold text-text-primary font-inter flex-wrap">
          <span>{stationDisplay(leg.fromCode, locale)}</span>
          <ArrowRight size={13} className="text-text-tertiary flex-shrink-0" />
          <span>{stationDisplay(leg.toCode, locale)}</span>
        </div>
        <TrainChips trains={leg.trains} jp={jp} />
      </div>
    </div>
  );
}

function TransferBadge({
  station,
  alternatives,
  jp,
  locale,
}: {
  station: Station;
  alternatives?: Station[];
  jp: JPDict;
  locale: Locale;
}) {
  return (
    <div className="ml-[42px] -mt-3 mb-2">
      <div className="flex items-center gap-2 flex-wrap">
        <ArrowsLeftRight size={13} className="text-text-tertiary flex-shrink-0" />
        <span className="text-xs text-text-secondary font-inter">
          {jp.change_at}{' '}
          <span className="font-semibold text-text-primary">{displayName(station, locale)}</span>
        </span>
        {station.isHub && (
          <Badge variant="info" className="!text-[10px]">
            {jp.hub_tag}
          </Badge>
        )}
      </div>
      {alternatives && alternatives.length > 0 && (
        <p className="text-[11px] text-text-tertiary mt-1 font-inter">
          {alternatives.length > 1 ? jp.alternative_interchanges : jp.alternative_interchange}{' '}
          {alternatives.map((s) => displayName(s, locale)).join(', ')}
        </p>
      )}
    </div>
  );
}

function DataDisclaimer({ note, jp }: { note: string; jp: JPDict }) {
  return (
    <div className="mt-4 flex gap-2.5 text-xs bg-accent/10 border border-accent/20 rounded-lg p-3.5">
      <Warning size={16} weight="fill" className="text-accent flex-shrink-0 mt-0.5" />
      <span className="text-text-secondary font-inter leading-relaxed">
        <strong className="text-text-primary font-semibold">{jp.schedules_may_change}</strong>{' '}
        {note}{' '}
        <a
          href="https://eticket.railway.gov.bd"
          target="_blank"
          rel="noopener noreferrer"
          className="underline text-primary hover:text-primary-dim font-medium"
        >
          {jp.verify_at}
        </a>
      </span>
    </div>
  );
}

// ─── Result renderers ─────────────────────────────────────────────────────────

function ResultShell({ type, jp, children }: { type: RouteType; jp: JPDict; children: React.ReactNode }) {
  return (
    <div className="bg-bg-card border border-border-subtle rounded-2xl p-5 sm:p-6 shadow-sm animate-fade-in-up">
      <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
        <RouteTypeBadge type={type} jp={jp} />
        {children}
      </div>
    </div>
  );
}

function DirectResult({ result, jp, locale }: { result: DirectJourney; jp: JPDict; locale: Locale }) {
  return (
    <div className="bg-bg-card border border-border-subtle rounded-2xl p-5 sm:p-6 shadow-sm animate-fade-in-up">
      <div className="flex items-center justify-between mb-4">
        <RouteTypeBadge type="direct" jp={jp} />
        <Badge variant={CONF_BADGE_VARIANT[result.overallConfidence]}>{jp[CONF_LABEL_KEY[result.overallConfidence]]}</Badge>
      </div>
      <LegCard leg={result.legs[0]} stepNumber={1} isLast jp={jp} locale={locale} />
      <ScoreBar score={result.confidenceScore} jp={jp} locale={locale} />
      <p className="text-xs text-text-tertiary mt-1.5 font-inter">{scoreExplain(result.confidenceScore, jp)}</p>
      <DataDisclaimer note={jp.data_note_direct} jp={jp} />
    </div>
  );
}

function OneTransferResult({ result, jp, locale }: { result: OneTransferJourney; jp: JPDict; locale: Locale }) {
  return (
    <div className="bg-bg-card border border-border-subtle rounded-2xl p-5 sm:p-6 shadow-sm animate-fade-in-up">
      <div className="flex items-center justify-between mb-4">
        <RouteTypeBadge type="one_transfer" jp={jp} />
        <Badge variant={CONF_BADGE_VARIANT[result.overallConfidence]}>{jp[CONF_LABEL_KEY[result.overallConfidence]]}</Badge>
      </div>
      <LegCard leg={result.legs[0]} stepNumber={1} isLast={false} jp={jp} locale={locale} />
      <TransferBadge station={result.transferStation} alternatives={result.alternativeTransfers} jp={jp} locale={locale} />
      <LegCard leg={result.legs[1]} stepNumber={2} isLast jp={jp} locale={locale} />
      <ScoreBar score={result.confidenceScore} jp={jp} locale={locale} />
      <p className="text-xs text-text-tertiary mt-1.5 font-inter">{scoreExplain(result.confidenceScore, jp)}</p>
      <DataDisclaimer note={jp.data_note_one_transfer} jp={jp} />
    </div>
  );
}

function TwoTransferResult({ result, jp, locale }: { result: TwoTransferJourney; jp: JPDict; locale: Locale }) {
  return (
    <div className="bg-bg-card border border-border-subtle rounded-2xl p-5 sm:p-6 shadow-sm animate-fade-in-up">
      <div className="flex items-center justify-between mb-4">
        <RouteTypeBadge type="two_transfer" jp={jp} />
        <Badge variant={CONF_BADGE_VARIANT[result.overallConfidence]}>{jp[CONF_LABEL_KEY[result.overallConfidence]]}</Badge>
      </div>
      <LegCard leg={result.legs[0]} stepNumber={1} isLast={false} jp={jp} locale={locale} />
      <TransferBadge station={result.transferStation1} jp={jp} locale={locale} />
      <LegCard leg={result.legs[1]} stepNumber={2} isLast={false} jp={jp} locale={locale} />
      <TransferBadge station={result.transferStation2} jp={jp} locale={locale} />
      <LegCard leg={result.legs[2]} stepNumber={3} isLast jp={jp} locale={locale} />
      <ScoreBar score={result.confidenceScore} jp={jp} locale={locale} />
      <p className="text-xs text-text-tertiary mt-1.5 font-inter">{scoreExplain(result.confidenceScore, jp)}</p>
      <DataDisclaimer note={jp.data_note_two_transfer} jp={jp} />
    </div>
  );
}

function NotFoundResultCard({
  result,
  jp,
  locale,
  originCode,
  destCode,
}: {
  result: NotFoundResult;
  jp: JPDict;
  locale: Locale;
  originCode: string;
  destCode: string;
}) {
  const hubLabel = result.nearestHubCode ? stationDisplay(result.nearestHubCode, locale) : null;
  const reason = jp.not_found_reason
    .replace('{from}', stationDisplay(originCode, locale))
    .replace('{to}', stationDisplay(destCode, locale));
  const suggestions = [
    hubLabel ? jp.not_found_suggestion_hub.replace('{hub}', hubLabel) : jp.not_found_suggestion_major_hub,
    jp.not_found_suggestion_incomplete,
    jp.not_found_suggestion_eticket,
  ];

  return (
    <div className="bg-bg-card border border-border-subtle rounded-2xl p-5 sm:p-6 shadow-sm animate-fade-in-up">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-9 h-9 rounded-full bg-bg-elevated border border-border-subtle flex items-center justify-center flex-shrink-0">
          <MagnifyingGlass size={16} className="text-text-tertiary" />
        </div>
        <div>
          <p className="text-text-primary font-semibold text-sm font-inter">{jp.not_found_title}</p>
          <RouteTypeBadge type="not_found" jp={jp} />
        </div>
      </div>
      <p className="text-sm text-text-secondary font-inter mb-3">{reason}</p>
      <ul className="space-y-2">
        {suggestions.map((s, i) => (
          <li key={i} className="flex gap-2 text-xs text-text-secondary font-inter">
            <ArrowRight size={13} className="text-primary flex-shrink-0 mt-0.5" />
            <span>{s}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ─── Station combobox ─────────────────────────────────────────────────────────

interface StationComboboxProps {
  id: string;
  label: string;
  placeholder: string;
  value: string;
  onChange: (code: string) => void;
  excludeCode?: string;
  locale: Locale;
  jp: JPDict;
  mirrorIcon?: boolean;
}

function StationCombobox({
  id,
  label,
  placeholder,
  value,
  onChange,
  excludeCode,
  locale,
  jp,
  mirrorIcon,
}: StationComboboxProps) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  // Keep the visible text in sync with the selected code — covers external
  // changes (swap button, popular-route chips) and locale toggles (so a
  // selected station's name flips language immediately).
  useEffect(() => {
    if (!value) {
      setQuery('');
      return;
    }
    setQuery(stationDisplay(value, locale));
  }, [value, locale]);

  const candidates = useMemo(
    () => STATIONS.filter((s) => s.code !== excludeCode),
    [excludeCode]
  );

  const options: Station[] = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      return [...candidates].sort((a, b) => {
        if (a.isHub !== b.isHub) return Number(b.isHub) - Number(a.isHub);
        return displayName(a, locale).localeCompare(displayName(b, locale));
      });
    }
    const scored = candidates
      .map((s) => {
        const nameEn = s.nameEn.toLowerCase();
        const nameBn = s.nameBn ?? '';
        const code = s.code.toLowerCase();
        let rank = -1;
        if (nameEn.startsWith(q) || nameBn.startsWith(query.trim())) rank = 0;
        else if (nameEn.includes(q) || nameBn.includes(query.trim()) || code.includes(q)) rank = 1;
        return { s, rank };
      })
      .filter((r) => r.rank >= 0)
      .sort((a, b) => (a.rank !== b.rank ? a.rank - b.rank : Number(b.s.isHub) - Number(a.s.isHub)));
    return scored.slice(0, 40).map((r) => r.s);
  }, [query, candidates, locale]);

  const hubOptions = options.filter((s) => s.isHub);
  const otherOptions = options.filter((s) => !s.isHub);
  const showGroups = query.trim().length === 0;

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    setHighlight(0);
  }, [query, open]);

  function select(s: Station) {
    onChange(s.code);
    setQuery(displayName(s, locale));
    setOpen(false);
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (!open && (e.key === 'ArrowDown' || e.key === 'Enter')) {
      setOpen(true);
      return;
    }
    if (!open) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlight((h) => Math.min(h + 1, options.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const s = options[highlight];
      if (s) select(s);
    } else if (e.key === 'Escape') {
      setOpen(false);
    }
  }

  return (
    <div className="flex-1 relative" ref={ref}>
      <label className="block text-text-tertiary text-[10px] font-bold uppercase tracking-widest mb-1.5 font-inter" htmlFor={id}>
        {label}
      </label>
      <div className="relative">
        <Train
          size={15}
          className="absolute left-3 top-1/2 -translate-y-1/2 text-primary/70 pointer-events-none"
          style={mirrorIcon ? { transform: 'translateY(-50%) scaleX(-1)' } : undefined}
        />
        <input
          id={id}
          type="text"
          role="combobox"
          aria-expanded={open}
          aria-controls={`${id}-listbox`}
          autoComplete="off"
          value={query}
          placeholder={placeholder}
          onFocus={(e) => {
            setOpen(true);
            e.target.select();
          }}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
            if (value) onChange('');
          }}
          onKeyDown={handleKeyDown}
          className="w-full h-12 pl-9 pr-8 rounded-xl text-sm font-inter bg-bg-elevated border border-border-subtle text-text-primary placeholder:text-text-tertiary focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/40 transition-all"
        />
        {query && (
          <button
            type="button"
            aria-label="Clear"
            onClick={() => {
              setQuery('');
              onChange('');
              setOpen(true);
            }}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-text-tertiary hover:text-text-primary transition-colors"
          >
            <X size={14} />
          </button>
        )}
      </div>

      {open && options.length > 0 && (
        <ul
          id={`${id}-listbox`}
          role="listbox"
          className="absolute top-full left-0 right-0 mt-1.5 rounded-xl overflow-hidden z-50 max-h-64 overflow-y-auto shadow-2xl bg-bg-card border border-border-strong"
        >
          {showGroups ? (
            <>
              {hubOptions.length > 0 && (
                <li className="px-3 pt-2.5 pb-1 text-[10px] uppercase tracking-widest text-text-tertiary font-inter font-bold" aria-hidden="true">
                  {jp.major_hubs_group}
                </li>
              )}
              {hubOptions.map((s) => {
                const idx = options.indexOf(s);
                return <StationOption key={s.code} s={s} active={idx === highlight} onSelect={select} locale={locale} />;
              })}
              {otherOptions.length > 0 && (
                <li className="px-3 pt-2.5 pb-1 text-[10px] uppercase tracking-widest text-text-tertiary font-inter font-bold" aria-hidden="true">
                  {jp.all_stations_group}
                </li>
              )}
              {otherOptions.map((s) => {
                const idx = options.indexOf(s);
                return <StationOption key={s.code} s={s} active={idx === highlight} onSelect={select} locale={locale} />;
              })}
            </>
          ) : (
            options.map((s, idx) => (
              <StationOption key={s.code} s={s} active={idx === highlight} onSelect={select} locale={locale} />
            ))
          )}
        </ul>
      )}
      {open && options.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-1.5 rounded-xl z-50 shadow-2xl bg-bg-card border border-border-strong px-4 py-3 text-sm text-text-tertiary font-inter">
          {jp.no_stations_found}
        </div>
      )}
    </div>
  );
}

function StationOption({
  s,
  active,
  onSelect,
  locale,
}: {
  s: Station;
  active: boolean;
  onSelect: (s: Station) => void;
  locale: Locale;
}) {
  return (
    <li role="option" aria-selected={active}>
      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          onSelect(s);
        }}
        className={`w-full text-left px-4 py-2.5 flex items-center justify-between gap-3 transition-colors group ${
          active ? 'bg-primary/10' : 'hover:bg-bg-elevated'
        }`}
      >
        <span className="flex items-center gap-2 min-w-0">
          <MapPin size={13} className="text-text-tertiary flex-shrink-0" />
          <span className={`text-sm font-inter truncate ${active ? 'text-primary font-medium' : 'text-text-primary'}`}>
            {displayName(s, locale)}
          </span>
        </span>
        <span className="text-text-tertiary font-mono text-[11px] flex-shrink-0">{s.code}</span>
      </button>
    </li>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

interface JourneyPlannerProps {
  initialOrigin?: string;
  initialDest?: string;
  className?: string;
}

export function JourneyPlanner({
  initialOrigin = '',
  initialDest = '',
  className = '',
}: JourneyPlannerProps) {
  const { t, locale } = useI18n();
  const jp = t.journey_planner;

  const [origin, setOrigin] = useState(initialOrigin);
  const [dest, setDest] = useState(initialDest);
  const [result, setResult] = useState<JourneyResult | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  const popularRoutes = useMemo(
    () =>
      POPULAR_ROUTE_CODES.filter(
        ([a, b]) => STATIONS.some((s) => s.code === a) && STATIONS.some((s) => s.code === b)
      ),
    []
  );

  const runSearch = useCallback((o: string, d: string) => {
    if (!o || !d || o === d) return;
    setOrigin(o);
    setDest(d);
    setIsSearching(true);
    setResult(null);
    window.setTimeout(() => {
      setResult(engine.find(o, d));
      setIsSearching(false);
    }, 500);
  }, []);

  const handleSearch = useCallback(() => runSearch(origin, dest), [origin, dest, runSearch]);

  const handleSwap = useCallback(() => {
    setOrigin(dest);
    setDest(origin);
    setResult(null);
  }, [origin, dest]);

  const canSearch = Boolean(origin && dest && origin !== dest);

  return (
    <section id="journey-planner" className={`relative pt-24 md:pt-28 pb-14 md:pb-20 overflow-hidden ${className}`}>
      {/* Ambient background glow — echoes the Hero section just below it */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden -z-10">
        <div className="absolute top-0 right-1/4 w-[500px] h-[500px] rounded-full bg-primary/6 blur-[130px]" />
        <div className="absolute -top-16 left-1/5 w-[360px] h-[360px] rounded-full bg-info/8 blur-[110px]" />
      </div>

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 md:mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-bold uppercase tracking-widest font-inter mb-5">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
            </span>
            {jp.overline}
          </div>

          <h2 className="text-text-primary font-extrabold leading-[1.15] text-3xl md:text-4xl lg:text-[42px] font-jakarta">
            {jp.headline} <span className="text-primary">{jp.headline_highlight}</span>
          </h2>

          <p className="mt-4 text-text-secondary text-base md:text-lg leading-relaxed font-inter">
            {jp.subtitle.replace('{count}', localizeNumber(STATIONS.length, locale))}
          </p>

          <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5">
            {[jp.feature_pill_1, jp.feature_pill_2, jp.feature_pill_3].map((pill) => (
              <span
                key={pill}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-bg-card border border-border-subtle text-text-secondary text-xs sm:text-[13px] font-medium font-inter"
              >
                <CheckCircle size={14} className="text-primary flex-shrink-0" weight="fill" />
                {pill}
              </span>
            ))}
          </div>
        </div>

        {/* Planner card + results */}
        <div className="max-w-3xl mx-auto">
          <div className="relative bg-bg-card border border-border-subtle rounded-2xl p-5 sm:p-7 shadow-lg shadow-primary/[0.04]">
            {/* Card header */}
            <div className="flex items-center gap-3 mb-5">
              <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center flex-shrink-0">
                <MapPin size={17} className="text-primary" weight="fill" />
              </div>
              <div>
                <p className="text-text-primary font-bold font-jakarta text-base leading-tight">{jp.card_title}</p>
                <p className="text-text-tertiary text-xs font-inter mt-0.5">
                  {jp.card_subtitle.replace('{count}', localizeNumber(STATIONS.length, locale))}
                </p>
              </div>
            </div>

            {/* From + Swap + To */}
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-end">
              <StationCombobox
                id="jp-origin"
                label={jp.from_label}
                placeholder={jp.from_placeholder}
                value={origin}
                onChange={(code) => {
                  setOrigin(code);
                  setResult(null);
                }}
                excludeCode={dest}
                locale={locale}
                jp={jp}
              />

              <button
                type="button"
                onClick={handleSwap}
                aria-label={jp.swap_aria}
                className="self-center sm:self-end mb-0 sm:mb-0.5 h-12 w-12 flex items-center justify-center border border-border-subtle rounded-xl text-text-tertiary hover:text-primary hover:border-primary/40 bg-bg-elevated transition-colors flex-shrink-0"
              >
                <ArrowsLeftRight size={17} />
              </button>

              <StationCombobox
                id="jp-dest"
                label={jp.to_label}
                placeholder={jp.to_placeholder}
                value={dest}
                onChange={(code) => {
                  setDest(code);
                  setResult(null);
                }}
                excludeCode={origin}
                locale={locale}
                jp={jp}
                mirrorIcon
              />
            </div>

            {/* Decorative rail track linking the two fields — animates while searching */}
            <div className="relative h-5 flex items-center px-1" aria-hidden="true">
              <div className="w-full border-t-2 border-dashed border-border-subtle" />
              {isSearching && (
                <Train
                  size={16}
                  weight="fill"
                  className="absolute -top-1.5 text-primary animate-train-move"
                  style={{ left: 0 }}
                />
              )}
            </div>

            {/* Popular routes */}
            {popularRoutes.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span className="text-[11px] text-text-tertiary font-inter mr-1">{jp.popular_routes_label}:</span>
                {popularRoutes.map(([a, b]) => (
                  <button
                    key={`${a}-${b}`}
                    type="button"
                    onClick={() => runSearch(a, b)}
                    className="inline-flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full bg-bg-elevated border border-border-subtle text-text-secondary hover:border-primary/40 hover:text-primary transition-colors font-inter"
                  >
                    {stationDisplay(a, locale)}
                    <ArrowRight size={10} />
                    {stationDisplay(b, locale)}
                  </button>
                ))}
              </div>
            )}

            {/* Submit */}
            <button
              type="button"
              onClick={handleSearch}
              disabled={!canSearch || isSearching}
              className="w-full h-12 mt-4 bg-primary hover:bg-primary-dim disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold font-inter text-sm rounded-xl transition-all flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-primary/20 active:scale-[0.98]"
            >
              {isSearching ? (
                <>
                  <CircleNotch size={16} weight="bold" className="animate-spin" />
                  {jp.finding_button}
                </>
              ) : (
                <>
                  <MagnifyingGlass size={16} weight="bold" />
                  {jp.find_button}
                </>
              )}
            </button>

            {!canSearch && (
              <p className="text-center text-text-tertiary text-xs font-inter mt-2.5">{jp.select_both_hint}</p>
            )}
            {canSearch && (
              <p className="text-center text-text-tertiary text-xs font-inter mt-2.5">
                {jp.cta_note.replace('{count}', localizeNumber(STATIONS.length, locale))}
              </p>
            )}
          </div>

          {/* Results */}
          {result && !isSearching && (
            <div className="mt-6" key={`${result.type}-${origin}-${dest}`}>
              {result.type === 'direct' && <DirectResult result={result} jp={jp} locale={locale} />}
              {result.type === 'one_transfer' && <OneTransferResult result={result} jp={jp} locale={locale} />}
              {result.type === 'two_transfer' && <TwoTransferResult result={result} jp={jp} locale={locale} />}
              {result.type === 'not_found' && (
                <NotFoundResultCard result={result} jp={jp} locale={locale} originCode={origin} destCode={dest} />
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

export default JourneyPlanner;
